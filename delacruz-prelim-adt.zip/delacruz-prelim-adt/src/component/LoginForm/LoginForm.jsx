import React, { useState, useRef, useCallback, useContext, createContext } from 'react';
import './LoginForm.css';
import Profile from '../Profile/Profile'; 

const ProfileContext = createContext();

function LoginForm({ firstName, middleName, lastName, secTion }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(false); 
  const usernameRef = useRef();
  const passwordRef = useRef();

  const handleLogin = useCallback((e) => {
    e.preventDefault();
    setLoading(true); 

    setTimeout(() => {
      if (username === 'user' && password === 'Password123@') {
        setIsLoggedIn(true);
      } else {
        alert('Invalid credentials, please try again');
      }
      setLoading(false); 
    }, 1500); 
  }, [username, password]);

  const handleShowPassword = useCallback(() => {
    setShowPassword((prevShowPassword) => !prevShowPassword);
  }, []);

  const handleLogout = useCallback(() => {
    const confirmLogout = window.confirm('Are you sure you want to log out?');
    if (confirmLogout) {
      setLoading(true); 
      setTimeout(() => {
        setIsLoggedIn(false);
        setUsername('');
        setPassword('');
        setLoading(false); 
      }, 1000); 
    }
  }, []);

  return (
    <ProfileContext.Provider value={{ firstName, middleName, lastName, secTion, username, isLoggedIn }}>
      <div className="login-container">
        <h2>{isLoggedIn ? 'Student Info' : 'Login'}</h2>

        {loading ? (
          <LoadingScreen /> 
        ) : !isLoggedIn ? (
          <form onSubmit={handleLogin}>
            <div>
              <label htmlFor="username">Username</label>
              <input
                type="text"
                id="username"
                ref={usernameRef}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                required
              />
            </div>
            <div>
              <label htmlFor="password">Password</label>
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                ref={passwordRef}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
              />
              <label>
                <input
                  type="checkbox"
                  checked={showPassword}
                  onChange={handleShowPassword}
                />
                Show Password
              </label>
            </div>
            <button type="submit">Login</button>
          </form>
        ) : (
          <ProfileDetails onLogout={handleLogout} />
        )}
      </div>
    </ProfileContext.Provider>
  );
}

function ProfileDetails({ onLogout }) {
  const { firstName, middleName, lastName, secTion } = useContext(ProfileContext);

  return (
    <div>
      <Profile firstname={firstName} middlename={middleName} lastname={lastName} section={secTion} />
      <button onClick={onLogout}>Logout</button>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="loading-screen">
      <div className="loading-spinner"></div>
      <p>Loading...</p>
    </div>
  );
}

export default LoginForm;
