import './Section.css';
function Section({section}) {
    return(
        <div>
            <h3>{section}</h3>
        </div>
    )
}

export default Section;