import './Name.css';
function Name({firstname, middlename, lastname}) {
    return(
        <div>
            <h3>{firstname} <span>{middlename}</span> <span>{lastname}</span></h3>
        </div>
    )
}

export default Name;