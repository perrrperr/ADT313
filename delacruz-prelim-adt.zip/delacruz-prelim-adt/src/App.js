import './App.css';
import LoginForm from './component/LoginForm/LoginForm';
import MathOperation from './component/MathOperation/MathOperation';
import Name from './component/StudentInformation/Name';
import Section from './component/StudentInformation/Section';

function App() {
  const studentInfo = {
    firstName: "Jasper Louis",
    middleName: "DC",
    lastName: "Dela Cruz",
    secTion: "BSIT - 3C"
  }
  return (
    <div className="App">
      <Name firstname={studentInfo.firstName} middlename={studentInfo.middleName} lastname={studentInfo.lastName}/>
      <Section section={studentInfo.secTion}/>
      <LoginForm firstName={studentInfo.firstName} middleName={studentInfo.middleName} lastName={studentInfo.lastName} secTion={studentInfo.secTion}/>
      <MathOperation/>
    </div>
  );
}

export default App;
